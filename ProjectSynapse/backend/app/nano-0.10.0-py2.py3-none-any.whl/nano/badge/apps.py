from django.apps import AppConfig

class NanoBadgeConfig(AppConfig):
    name = 'nano.badge'
    verbose_name = "Badge"

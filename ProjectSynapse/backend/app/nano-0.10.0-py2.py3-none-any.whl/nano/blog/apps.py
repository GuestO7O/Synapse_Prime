from django.apps import AppConfig

class NanoBlogConfig(AppConfig):
    name = 'nano.blog'
    verbose_name = "Blog"

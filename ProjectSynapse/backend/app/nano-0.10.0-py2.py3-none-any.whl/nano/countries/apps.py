from django.apps import AppConfig

class NanoCountriesConfig(AppConfig):
    name = 'nano.countries'
    verbose_name = "Countries"

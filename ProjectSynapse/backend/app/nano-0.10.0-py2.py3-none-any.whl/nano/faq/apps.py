from django.apps import AppConfig

class NanoFaqConfig(AppConfig):
    name = 'nano.faq'
    verbose_name = "Faq"

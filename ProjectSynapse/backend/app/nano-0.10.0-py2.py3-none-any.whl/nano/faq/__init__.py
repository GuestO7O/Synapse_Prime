default_app_config = 'nano.faq.apps.NanoFaqConfig'

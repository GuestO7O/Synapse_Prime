from django.apps import AppConfig

class NanoUserConfig(AppConfig):
    name = 'nano.user'
    verbose_name = "User"

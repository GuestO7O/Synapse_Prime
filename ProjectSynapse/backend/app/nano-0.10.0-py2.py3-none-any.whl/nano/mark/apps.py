from django.apps import AppConfig

class NanoMarkConfig(AppConfig):
    name = 'nano.mark'
    verbose_name = "Mark"

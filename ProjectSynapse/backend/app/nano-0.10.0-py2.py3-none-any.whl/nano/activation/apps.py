from django.apps import AppConfig

class NanoActivationConfig(AppConfig):
    name = 'nano.activation'
    verbose_name = "Activation"

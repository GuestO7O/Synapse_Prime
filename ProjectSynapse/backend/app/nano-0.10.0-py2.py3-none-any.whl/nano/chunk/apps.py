from django.apps import AppConfig

class NanoChunkConfig(AppConfig):
    name = 'nano.chunk'
    verbose_name = "Chunk"

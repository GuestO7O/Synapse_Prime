default_app_config = 'nano.privmsg.apps.NanoPrivmsgConfig'

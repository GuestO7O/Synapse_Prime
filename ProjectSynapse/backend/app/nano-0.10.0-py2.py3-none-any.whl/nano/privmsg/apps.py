from django.apps import AppConfig

class NanoPrivmsgConfig(AppConfig):
    name = 'nano.privmsg'
    verbose_name = "Privmsg"

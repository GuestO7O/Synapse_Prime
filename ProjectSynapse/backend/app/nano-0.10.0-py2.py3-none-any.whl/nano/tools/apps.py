from django.apps import AppConfig

class NanoToolsConfig(AppConfig):
    name = 'nano.tools'
    verbose_name = "Tools"

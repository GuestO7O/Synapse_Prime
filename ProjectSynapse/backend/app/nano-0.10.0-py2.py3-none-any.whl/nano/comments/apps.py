from django.apps import AppConfig

class NanoCommentsConfig(AppConfig):
    name = 'nano.comments'
    verbose_name = "Comments"
